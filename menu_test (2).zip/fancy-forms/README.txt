A Pen created at CodePen.io. You can find this one at http://codepen.io/adam2326/pen/VYMOdx.

 Material design style form elements 