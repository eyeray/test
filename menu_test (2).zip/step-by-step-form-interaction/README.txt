A Pen created at CodePen.io. You can find this one at http://codepen.io/balapa/pen/XbXVRg.

 A simple step form for customer experience. The purpose of this form is to get the feedback from user for the store.

Thanks for watching!