(function($) {
  'use strict';

  // Selectmenu
  $('select').selectmenu();
  
}(jQuery));