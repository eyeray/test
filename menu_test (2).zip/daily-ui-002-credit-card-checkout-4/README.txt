A Pen created at CodePen.io. You can find this one at http://codepen.io/marcobiedermann/pen/XmOdNP.

 View it at <a href="https://dribbble.com/shots/2349478-Daily-UI-002-Credit-Card-Checkout">dribbble</a> or <a href="https://www.behance.net/gallery/31249393/Daily-UI-002-Credit-Card-Checkout">Behance</a>