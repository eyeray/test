A Pen created at CodePen.io. You can find this one at http://codepen.io/sntran/pen/mydoYG.

 Not my own. I only collected it from http://thecodeplayer.com/walkthrough/single-input-3d-form